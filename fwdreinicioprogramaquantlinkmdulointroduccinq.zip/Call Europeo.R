MU = 0.05
SIGMA = 0.03
R = 0.04
S0 = 100
B0 = 85
K = 99
h = 12
Tt = 2
T = Tt*h
 
mu = (1+MU)^(1/h)-1
sigma = (1+SIGMA)^(1/h)-1
r = (1+R)^(1/h)-1
 
B = function(t){ B0*exp(t*r)}
 
W = function(t){ if(t==0) {0} else W(t-1)+rnorm(1,0,1)}
 
wt = W(t)
 
S = function(t){S0*exp(mu*t+sigma*wt)}
 
Ws = function(t) {wt+((mu-r+0.5*sigma**2)/sigma)*(t)}
 
wst= Ws(t)
 
Ss = function (t) {S0*exp((r-0.5*sigma**2)*(t)+sigma*wst)}
 
phi = function (t) { pnorm((log(Ss(t)/K)+(r+0.5*sigma**2)*(T-t))/((sigma*(T-t))**0.5),0,T-t)  }
 
V = function (t) { Ss(t)*phi(t)-K*exp(-r*(T-t))*phi(t)}
 
psi = function (t) { (V(t)-phi(t)*Ss(t))/B(t) }
 
X = function (t) {max(S(t)-K,0)}

 
time = 0
Wt = 0
Wst = 0
Bt = 0
St = 0
Sst = 0
phit = 0
psit = 0
Vt = 0
Xt = 0
 
for (t in 0:T) {
time = rbind(time,t)
Wt = rbind(Wt,W(t))
Wst = rbind(Wst,Ws(t))
Bt = rbind(Bt,B(t))
St = rbind(St,S(t))
Sst = rbind(Sst,Ss(t))
phit = rbind(phit,phi(t))
psit = rbind(psit,psi(t))
Vt = rbind(Vt,V(t))
Xt = rbind(Xt,X(t))     }
 
Table = cbind(time,Wt,Wst,Bt,St,Sst,phit,psit,Vt,Xt)
 
print(Table)
